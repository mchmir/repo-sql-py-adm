using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace GGSLC
{
	public class Site1 : MasterPage
	{
		protected ContentPlaceHolder head;

		protected HtmlForm form1;

		protected ContentPlaceHolder ContentPlaceHolder1;

		protected ContentPlaceHolder ContentPlaceHolder6;

		protected ImageButton ImageButton1;

		protected ImageButton ImageButton2;

		protected ContentPlaceHolder ContentPlaceHolder5;

		protected ContentPlaceHolder ContentPlaceHolder3;

		protected ContentPlaceHolder ContentPlaceHolder8;

		protected ContentPlaceHolder ContentPlaceHolder9;

		public Site1()
		{
		}

		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}