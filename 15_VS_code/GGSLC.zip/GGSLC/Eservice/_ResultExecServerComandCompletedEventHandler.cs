using System;
using System.CodeDom.Compiler;
using System.ComponentModel;

namespace GGSLC.Eservice
{
	[GeneratedCode("System.Web.Services", "4.6.1055.0")]
	public delegate void _ResultExecServerComandCompletedEventHandler(object sender, AsyncCompletedEventArgs e);
}