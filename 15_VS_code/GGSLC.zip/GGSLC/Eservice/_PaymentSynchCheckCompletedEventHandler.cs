using System;
using System.CodeDom.Compiler;

namespace GGSLC.Eservice
{
	[GeneratedCode("System.Web.Services", "4.6.1055.0")]
	public delegate void _PaymentSynchCheckCompletedEventHandler(object sender, _PaymentSynchCheckCompletedEventArgs e);
}