using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace GGSLC
{
	public class notWork : System.Web.UI.Page
	{
		protected HtmlForm form1;

		public notWork()
		{
		}

		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}